#ifndef F_CPU
#define F_CPU 16000000UL
#endif
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

float adc_value;

void ADC_Init()
{
	ADMUX=(1<<REFS1);											 // Selecting internal reference voltage (1.1V)
	ADCSRA=(1<<ADIE)|(1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // Enable ADC also set Prescaler as 128 and AD interruptions are enabled
	ADMUX=0x40;													 // Channel A0 selected
	ADCSRA|=(1<<ADSC);											 // ADSC is set to 1 to start next conversion
}

void Ports_Setup()
{
	//SALIDAS ~ VALOR 1
	DDRC=0b11111111; //SEGMENTOS DISPLAY
	DDRD=0b00000011; //CONTROL DIGITO 1 Y 2
	
	//ENTRADA ~ VALOR 0
	DDRF=0b00000000; //PIN ANAL�GICO DEL POT.
}

int main(void)
{
	Ports_Setup();
	ADC_Init();
	sei();
	
	const uint8_t DisplayCC[10] =
	{0b11101111, 0b00101100, 0b10110111, 0b10111110, 0b01111100,
	0b11011110, 0b11011111, 0b10101100, 0b11111111, 0b11111100};
	//ARRAY ADAPTADO A MIS CONEXIONES. POS. DE 0 A 9
	
	const uint8_t *pDisplayCC= &DisplayCC; //PUNTERO DEL ARRAY "DisplayCC"
	uint8_t pot1, pot2, pdecimal= 0b11111011; //"pdecimal" ELIMINA EL PUNTO DEL DIGITO DECIMAL

	while (1)
	{
		//CONTROL DIGITO ENTERO
		pot1= adc_value*5/1024;
		PORTD=0b11111110;
		PORTC=*(pDisplayCC+pot1);
		_delay_ms(1);

		PORTC=0b00000000;

		//CONTROL DIGITO DECIMAL
		PORTD=0b11111101;
		pot2= 10*(adc_value*5.0/1024-pot1);
		PORTC=(*(pDisplayCC+pot2) & pdecimal);
		_delay_ms(1);
	}
}

ISR(ADC_vect)
{
	adc_value=ADC;
	ADCSRA |= (1<<ADSC);										// ADSC is set to 1 to start next conversion
}