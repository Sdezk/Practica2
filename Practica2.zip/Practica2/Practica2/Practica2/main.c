#ifndef F_CPU
#define F_CPU 16000000UL
#endif
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>	

unsigned int ADC_read(unsigned char chnl)
{
	chnl= chnl & 0b00000111; // select adc channel between 0 to 7
	ADMUX = 0b01000000;        //channel A0 selected
	ADCSRA|=(1<<ADSC);   // start conversion
	while(!(ADCSRA & (1<<ADIF)));   // wait for ADIF conversion complete return
	ADCSRA|=(1<<ADIF);   // clear ADIF when conversion complete by writing 1
	return (ADC); //return calculated ADC value
}

void Ports_Setup()
{
	//SALIDAS ~ VALOR 1
	DDRC=0b11111111; //SEGMENTOS DISPLAY
	DDRD=0b00000011; //CONTROL DIGITO 1 Y 2
	
	//ENTRADA ~ VALOR 0
	DDRF=0b00000000; //PIN ANAL�GICO DEL POT.
}

int main(void)
{
Ports_Setup();
const unsigned int DisplayCC[10] =
	{0b11101111, 0b00101100, 0b10110111, 0b10111110, 0b01111100,
	 0b11011110, 0b11011111, 0b10101100, 0b11111111, 0b11111100};
	 //ARRAY ADAPTADO A MIS CONEXIONES. POS. DE 0 A 9
	 
const unsigned int *pDisplayCC= &DisplayCC; 
unsigned int pot1, pot2;

ADMUX=(1<<REFS0);      
ADCSRA=(1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);

while (1) 
    {
		//CONTROL DIGITO ENTERO
		pot1= ADC_read(0)*5/1024;
		PORTD=0b11111110;
		PORTC=*(pDisplayCC+pot1);
		_delay_ms(5);

		//CONTROL DIGITO DECIMAL
		PORTD=0b11111101;
		pot2= 10*(ADC_read(0)*5.0/1024-pot1);
		PORTC=*(pDisplayCC+pot2);
		_delay_ms(5);
    }
}